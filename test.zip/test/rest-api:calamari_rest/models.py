#!/usr/bin/env python
# -*- coding:utf-8 -*-

# This file just exists to make manage.py happy
import logging
import datetime
import pytz
import uuid
import hmac
import hashlib
from django.utils.timezone import now
LOG = logging.getLogger('django.request')

from django.db import models
from django.db import IntegrityError
from django.core.exceptions import ObjectDoesNotExist, MultipleObjectsReturned


class Task_For_Django(models.Model):
    # status must be one of the following status
    status_choice = {'WAITING': 1, 'RUNNING': 2, 'COMPLETED': 3}
    id = models.AutoField(primary_key=True)
    uuid = models.CharField(max_length=36, unique=True, null=True)
    name_en = models.TextField(default="", null=True)
    name_cn = models.TextField(default="", null=True)
    request = models.TextField(default="", null=True)
    status = models.PositiveIntegerField(null=True,blank=True)
    progress = models.PositiveIntegerField(null=True,blank=True)
    progress_desc_en = models.TextField(default="", null=True)
    progress_desc_cn = models.TextField(default="", null=True)
    create_time = models.DateTimeField(null=True,blank=True)
    start_time = models.DateTimeField(null=True,blank=True)
    end_time = models.DateTimeField(null=True,blank=True)
    success = models.NullBooleanField(default=None)
    error_code = models.IntegerField(null=True, blank=True)
    error_reason_en = models.TextField(default="", null=True)
    error_reason_cn = models.TextField(default="", null=True)

    class Meta:
        db_table = 'task'

        def __init__(self):
            pass

    def __repr__(self):
        try:
            r = '{t.id}, {t.uuid}, {t.name_en}, {t.name_cn}, {t.request}, ' \
                '{t.status}, {t.progress}, {t.progress_desc_en}, {t.progress_desc_cn}, ' \
                '{t.create_time}, {t.start_time}, {t.end_time}, {t.success}, ' \
                '{t.error_code}, {t.error_reason_en}, {t.error_reason_cn}' \
                .decode('utf8').format(t=self)
            return r.encode('utf8')
        except Exception as e:
            LOG.exception('unknown error: {}'.format(e))
            return 'error occurred'


class Task(models.Model):
    name = models.CharField(max_length=100)

    def __unicode__(self):
        return self.name

    class Meta:
        permissions = (
            ('operate_syslog', 'operate_syslog'),
            ('operate_operationlog', 'operate_operationlog'),
            ('operate_pool', 'operate_pool'),
            ('operate_pool_rbd', 'operate_pool_rbd'),
            ('operate_pool_objs', 'operate_pool_objs'),
            ('operate_pool_policy', 'operate_pool_policy'),
            ('operate_host', 'operate_host'),
            ('operate_topo', 'operate_topo'),
            ('operate_monitor', 'operate_monitor'),
            ('operate_alarm', 'operate_alarm'),
            ('operate_alarm_config', 'operate_alarm_config'),
            ('operate_highavailable', 'operate_highavailable'),
            ('operate_files', 'operate_files'),
            ('operate_paramConfig', 'operate_paramConfig'),
            ('operate_backup_cfg', 'operate_backup_cfg'),
            ('operate_backup_policy', 'operate_backup_policy'),
            ('operate_partition', 'operate_partition'),
            ('operate_snmp', 'operate_snmp'),
            ('operate_multi_cluster', 'operate_multi_cluster'),
            ('operate_auditlog', 'operate_auditlog')
        )


class HandyHA(models.Model):
    """
    HandyHA的PSQL表
    """
    vip = models.CharField(max_length=128)
    master = models.CharField(max_length=128)
    master_public_ip = models.CharField(max_length=128)
    slave = models.CharField(max_length=128)
    slave_public_ip = models.CharField(max_length=128)
    vrid = models.CharField(max_length=128)
    priority_list = models.CharField(max_length=128)

    def __unicode__(self):
        """
        unicode值
        """
        return self.name


class Language(models.Model):
    """
    当前语言的PSQL表
    """
    language = models.CharField(max_length=128)


class SsoConfig(models.Model):
    """
    单点登录配置信息
    """
    login_url = models.CharField(max_length=256)
    logout_url = models.CharField(max_length=256)
    auth_url = models.CharField(max_length=256)

    def __unicode__(self):
        return self.login_url


class Session(models.Model):
    """
    单点登录Session信息
    """
    session_id = models.CharField(max_length=64)
    session_key = models.CharField(max_length=256)

    def __unicode__(self):
        return self.session_key


class UserLoginPermit(models.Model):
    """
    用户登录控制数据记录
    reserv1， reserve2 该字段当前未使用，用于严格等待限制预留字段
    """
    # 登录的客户端IP
    login_ip = models.IPAddressField(primary_key=True)
    # 登录次数
    login_count = models.IntegerField()
    # 上次登录时间，使用时间戳
    last_login_time = models.BigIntegerField()
    # 保留项
    reserv1 = models.CharField(max_length=64, default='')
    reserv2 = models.CharField(max_length=64, default='')


class UserLoginPermitPersist:
    """
    用户登录实例化操作方法
    """
    def __init__(self):
        pass

    @staticmethod
    def filter_ip_one(client_ip):
        """
        根据IP获取数据，仅返回一条
        :return: Dict
        """
        query_info = None
        try:
            query_info = UserLoginPermit.objects.get(login_ip=client_ip)
        except ObjectDoesNotExist:
            LOG.debug("client ip '%s' is first login or not saved in database", client_ip)
        except MultipleObjectsReturned:
            LOG.error("client ip '%s' is multiple, please check.", client_ip)

        if query_info:
            return {
                'login_ip': query_info.login_ip,
                'login_count': query_info.login_count,
                'last_login_time': query_info.last_login_time
            }
        return None

    def update_or_save(self, client_info=None):
        """
        若IP信息已经存在，则更新，否则添加
        :param client_info: Dict，一条信息
        :return: None
        """
        if not client_info:
            return False
        # 若已经存在客户端登录IP，则只需要更新键值即可
        exist_info = self.filter_ip_one(client_ip=client_info['login_ip'])
        if exist_info:
            UserLoginPermit.objects.filter(login_ip=client_info['login_ip']).update(
                login_count=client_info['login_count'], last_login_time=client_info['last_login_time'])
        else:
            try:
                UserLoginPermit.objects.create(login_ip=client_info['login_ip'], login_count=client_info['login_count'],
                                               last_login_time=client_info['last_login_time'])
            except IntegrityError as error:
                LOG.error('save client login meet error, detail is: %s', error)
            except Exception as error:
                LOG.error('save client login meet error, detail is: %s', error)



class KmsAuthToken(models.Model):
    """
    对象网关秘钥管理认证token信息
    """
    key = models.CharField(max_length=40,primary_key=True)
    created = models.DateTimeField(auto_now_add=True)
    modified = models.DateTimeField(auto_now_add=True)
    expires = models.DateTimeField(default=now)
    request_hash = models.CharField(max_length=40,blank=True,default=None)
    username = models.CharField(max_length=256)

    @classmethod
    def get_request_hash(cls,request):
        SECRET_KEY = '1u@_1_p44@&x+m4o3w*+oenj4d0#r5l(6e%z34@aezxist6_0m'
        REMOTE_HOST_HEADERS = ['REMOTE_ADDR','REMOTE_HOST']
        h = hashlib.sha1()
        h.update(SECRET_KEY)
        for header in REMOTE_HOST_HEADERS:
            value = request.META.get(header,'').split(',')[0].strip()
            if value:
                h.update(value)
                break
        h.update(request.META.get('HTTP_USER_AGENT',''))
        return h.hexdigest()

    def save(self, *args,**kwargs):
        if not self.pk:
            self.refresh(save=False)
        if not self.key:
            self.key = self.generate_key()
        return super(KmsAuthToken, self).save(*args, **kwargs)

    def refresh(self,save=True):
        KMS_AUTH_TOKEN_EXPIRATION = 1800
        if not self.pk or not self.expired:
            self.expires = datetime.datetime.now(pytz.utc) + datetime.timedelta(seconds=KMS_AUTH_TOKEN_EXPIRATION)
            if save:
                self.save()

    def generate_key(self):
        unique = uuid.uuid4()
        return hmac.new(unique.bytes, digestmod=hashlib.sha1).hexdigest()

    @property
    def expired(self):
        return bool(self.expires < datetime.datetime.now())

    def __unicode__(self):
        return self.key
