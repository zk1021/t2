import logging
import datetime
import pytz
import traceback
from rest_framework import status
from rest_framework import exceptions
from rest_framework import authentication
from rest_framework import  HTTP_HEADER_ENCODING
from rest_framework.decorators import permission_classes
from rest_framework.decorators import api_view
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from django.views.decorators.cache import never_cache
from django.contrib.auth.hashers import make_password, check_password
from django.utils import timezone
from calamari_rest.models import KmsAuthToken
from calamari_rest.obs import leader_router
from calamari_rest.views.common.forward import ForwardView
from calamari_rest.views.common.forward import LOG_KEY
from calamari_rest.obs.views import normalizer
from rest_framework.renderers import BaseRenderer, JSONRenderer
from django.conf import settings


logger = logging.getLogger('django.request')
RGW_ADMIN_USERNAME = 'rgwadmin'
RGW_ADMIN_PASSWORD = 'pbkdf2_sha256$24000$h3c$BVSECToWBRokfVBdwHuoqNOW5PCs4Nanp2C5/XJQqiw='
KMS_TOKNE_DICT = {
    "access": {
        "token": {
            "expires": None,
            "id": None,
            "tenant": {
                "description": '',
                "enabled": True,
                "id": 1,
                "name": None
            },
        },
        "user": {
            "username": None,
            "roles_links": [],
            "id": 3,
            "roles": [
            ],
            "name": None
        }
    }
}



class BinaryRenderer(BaseRenderer):
    media_type = 'application/octet-stream'
    charset = None
    format = '.bin'

    def render(self, data, media_type=None, renderer_context=None):
        return data


@api_view(['POST'])
@permission_classes((AllowAny,))
@never_cache
def get_token(request):
    username, password, rgw_tenant =  None, None, None
    logger.info("kms get token request data: {}".format(request.DATA))
    auth_info = request.DATA.get('auth')
    if auth_info:
        credential = auth_info.get('passwordCredentials')
        rgw_tenant = auth_info.get('tenantName')
        if credential:
            username = credential.get('username')
            password = credential.get('password')
    request.DATA['username'] = username
    request.DATA['password'] = password
    auth_failed_response = Response(
        {'error': 'unable to login with given credentials'}, status=status.HTTP_400_BAD_REQUEST
    )

    try:
        if is_auth_valid(username, password):
            request_hash = KmsAuthToken.get_request_hash(request)
            try:
                token = KmsAuthToken.objects.filter(
                    username=username, request_hash=request_hash, expires__gt=datetime.datetime.now(pytz.utc)
                )[0]
                token.refresh()
            except IndexError:
                token = KmsAuthToken.objects.create(username=username, request_hash=request_hash)
            user_agent = request.META.get('HTTP_USER_AGENT','')
            KMS_TOKNE_DICT['access']['token']['expires'] = token.expires
            KMS_TOKNE_DICT['access']['token']['id'] = token.key
            KMS_TOKNE_DICT['access']['token']['tenant']['name'] = rgw_tenant
            KMS_TOKNE_DICT['access']['user']['username'] = username
            KMS_TOKNE_DICT['access']['user']['id'] = 3
            KMS_TOKNE_DICT['access']['user']['name'] = username
            return Response(KMS_TOKNE_DICT)
        else:
            logger.error("kms authencate failed!")
            return auth_failed_response
    except Exception:
        logger.error("kms get token failed: {}".format(traceback.format_exc()))
        return auth_failed_response


class KmsSecretViewSet(ForwardView):
    renderer_classes = (JSONRenderer, BinaryRenderer)
    permission_classes = (AllowAny, )

    def __init__(self, *args, **kwargs):
        super(KmsSecretViewSet, self).__init__(*args, **kwargs)
        self.leader_router = leader_router

    def get(self, request, *args, **kwargs):
        logger.info("get secret payload request meta: {}".format(request.META))
        try:
            result = KmsTokenAuthentication().authenticate(request)
        except Exception:
            logger.error("token validate failed: {}".format(traceback.format_exc()))
            return Response({'error': 'unable to login with given credentials'}, status=status.HTTP_400_BAD_REQUEST)

        secret_key = request.path.split('v1/secrets/')[1]
        data = {
           'secret_key': secret_key,
           'HTTP_ACCEPT': request.META.get('HTTP_ACCEPT')
        }
        try:
            comp_op = self.leader_router.OP_KMS_SECRET_PAYLOAD_QUERY
            for key in data:
                if data[key] == 'false':
                    data[key] = False
                elif data[key] == 'true':
                    data[key] = True
            data[LOG_KEY] = False
            response = self.send_request_to_leader(comp_op, data, request, is_get=True)
            data = response.data['data']
            secret = data.get('secret')
            content_type = data.get('content_type')
            payload =  normalizer.denormalize_after_decryption(secret, content_type)
            return Response(data=payload)
        except Exception:
            logger.error("get secret payload failed: {}".format(traceback.format_exc()))
            return Response({"error": "get secret payload failed!"})


class KmsTokenAuthentication(authentication.TokenAuthentication):
    model = KmsAuthToken

    def get_kms_auth_token_header(self,request):
        auth_token = request.META.get('HTTP_X_AUTH_TOKEN','')
        if isinstance(auth_token,str):
            auth_token = auth_token.encode(HTTP_HEADER_ENCODING)
        return auth_token

    def authenticate(self,request):
        self.request = request
        auth_token = self.get_kms_auth_token_header(request).split()

        if not auth_token or auth_token[0].lower() != 'token':
            if not auth_token:
                auth_token = authentication.get_authorization_header(request).split()
                if not auth_token or auth_token[0].lower() != 'token':
                    logger.error("kms token authenticate error: No Token!")
                    raise exceptions.AuthenticationFailed('No Token!')
            auth_token.insert(0, 'token')
        if len(auth_token) == 1 or len(auth_token) > 2:
            msg = 'Invalid token'
            logger.error("kms token {} is invalid!".format(auth_token))
            raise exceptions.AuthenticationFailed(msg)

        token_username, token = self.authenticate_credentials(auth_token[1])
        return (token_username, token)

    def authenticate_credentials(self, key):
        try:
            request_hash = self.model.get_request_hash(self.request)
            token = self.model.objects.get(key=key, request_hash=request_hash)
        except self.model.DoesNotExist:
            logger.error("kms token does not exist!")
            raise exceptions.AuthenticationFailed('Invalid token')

        if token.expired:
            logger.error("kms token is expired!")
            raise exceptions.AuthenticationFailed('Token is expired or Token is Old')
        token.refresh()
        return (token.username, token)


def is_auth_valid(username, password):
    if username != RGW_ADMIN_USERNAME:
        return False
    return check_password(password, RGW_ADMIN_PASSWORD)
