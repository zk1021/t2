#!/usr/bin/env python
# -*- coding: utf-8 -*-

import calamari_rest.obs.views.kms
from django.conf.urls import patterns, url

urlpatterns = patterns(
    '',
    url(r'^token', calamari_rest.obs.views.kms.get_token),
    url(r'^secrets/[0-9a-z-]+$', calamari_rest.obs.views.kms.KmsSecretViewSet.as_view(
        {'get': 'get'})),
)
